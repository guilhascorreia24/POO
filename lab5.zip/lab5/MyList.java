public interface MyList{
    /**
     * tamanho da lista
     */
    int size();
    /**
     * limpa a lista
     */
    void clear();
    /**
     * 
     * @param i index do elemento na lista
     * @return devolve o Objecto correspondente
     */
    Object getfirstElementOf(int i);
    /**
     * 
     * @param o Objecto que queremos procurar
     * @param i index 
     * @return 
     */
    boolean contains(Object o, int i);
}