public interface iMatrix {
	/**
	 * 
	 * @param m matriz que é recebida no inicio da iteracao
	 */
	public void set(int[][] m);

	/**
	 * esta funcao da o resultado da iteracao
	 */
	public int[][] get();
}
